# Copyright 2022 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================


import os
import numpy as np
import mindspore as ms
from mindspore import context, Tensor, Model, nn, ops
from mindspore.common.initializer import Normal
from tqdm import tqdm
import argparse
from trainers import EBMRecTrainer
from utils import EarlyStopping, get_local_time, get_rating_matrix
from datasets import get_dataloader, get_seq_dic
from modules import LayerNorm

class End4RecModel(nn.Cell):
    def __init__(self, hidden_size, max_seq_length, hidden_act, num_hidden_layers, item_size, behavior_size, position_size, initializer_range, cuda_condition):
        super(End4RecModel, self).__init__()
        self.hidden_size = hidden_size
        self.max_seq_length = max_seq_length
        self.hidden_act = hidden_act
        self.num_hidden_layers = num_hidden_layers
        self.item_size = item_size
        self.behavior_size = behavior_size
        self.position_size = position_size
        self.initializer_range = initializer_range
        self.cuda_condition = cuda_condition

        self.item_embeddings = nn.Embedding(item_size, hidden_size, padding_idx=0)
        self.behavior_embeddings = nn.Embedding(behavior_size, hidden_size, padding_idx=0)
        self.position_embeddings = nn.Embedding(max_seq_length, hidden_size)
        self.LayerNorm = LayerNorm(hidden_size, eps=1e-12)
        self.dropout = nn.Dropout(p=0.1)

        self.ebm = EfficientBehaviorSequenceMiner(hidden_size, max_seq_length, hidden_act, num_hidden_layers, cuda_condition)
        self.hne = HardNoiseEliminator(hidden_size)
        self.snf = SoftNoiseFilter(hidden_size)

    def add_position_embedding(self, sequence, behavior_sequence):
        seq_length = sequence.shape[1]
        position_ids = Tensor(np.arange(seq_length), ms.int32)
        broadcast_to = ops.BroadcastTo(sequence.shape)
        position_ids = broadcast_to(position_ids.expand_dims(0))
        
        item_embeddings = self.item_embeddings(sequence)
        behavior_embeddings = self.behavior_embeddings(behavior_sequence)
        position_embeddings = self.position_embeddings(position_ids)
        
        sequence_emb = item_embeddings + behavior_embeddings + position_embeddings
        sequence_emb = self.LayerNorm(sequence_emb)
        sequence_emb = self.dropout(sequence_emb)

        return sequence_emb

    def construct(self, input_ids, behavior_ids):
        sequence_emb = self.add_position_embedding(input_ids, behavior_ids)
        sequence_emb = self.ebm(sequence_emb)
        sequence_emb = self.hne(sequence_emb)
        sequence_emb = self.snf(sequence_emb)
        return sequence_emb

class EfficientBehaviorSequenceMiner(nn.Cell):
    def __init__(self, hidden_size, max_seq_length, hidden_act, num_hidden_layers, cuda_condition):
        super(EfficientBehaviorSequenceMiner, self).__init__()
        self.hidden_size = hidden_size
        self.max_seq_length = max_seq_length
        self.hidden_act = hidden_act
        self.num_hidden_layers = num_hidden_layers
        self.cuda_condition = cuda_condition

        self.fft = ops.FFT()
        self.ifft = ops.IFFT()
        self.chunked_diagonal = ChunkedDiagonal(hidden_size, max_seq_length)
        self.compactness_regularization = CompactnessRegularization(hidden_size, max_seq_length)

    def construct(self, sequence_emb):
        freq_domain = self.fft(sequence_emb)
        freq_domain = self.chunked_diagonal(freq_domain)
        freq_domain = self.compactness_regularization(freq_domain)
        sequence_emb = self.ifft(freq_domain)

        return sequence_emb

class ChunkedDiagonal(nn.Cell):
    def __init__(self, hidden_size, max_seq_length):
        super(ChunkedDiagonal, self).__init__()
        self.hidden_size = hidden_size
        self.max_seq_length = max_seq_length
        self.chunk_size = hidden_size // 4 

    def construct(self, freq_domain):
        k = self.chunk_size
        chunks = []
        for i in range(0, self.hidden_size, k):
            chunk = freq_domain[:, :, i:i+k]
            chunk = ops.matmul(chunk, self.weight)
            chunks.append(chunk)
        freq_domain = ops.concat(chunks, axis=-1)
        return freq_domain

class CompactnessRegularization(nn.Cell):
    def __init__(self, hidden_size, max_seq_length):
        super(CompactnessRegularization, self).__init__()
        self.hidden_size = hidden_size
        self.max_seq_length = max_seq_length

    def construct(self, freq_domain):
        regularization_loss = ops.reduce_mean(ops.abs(freq_domain))
        return freq_domain, regularization_loss

class HardNoiseEliminator(nn.Cell):
    def __init__(self, hidden_size):
        super(HardNoiseEliminator, self).__init__()
        self.hidden_size = hidden_size
        self.token_scorer = nn.Dense(hidden_size, 1)
        self.gumbel_softmax = ops.GumbelSoftmax(dim=1)

    def construct(self, sequence_emb):
        token_scores = self.token_scorer(sequence_emb)
        token_scores = self.gumbel_softmax(token_scores)
        sequence_emb = sequence_emb * token_scores
        return sequence_emb

class SoftNoiseFilter(nn.Cell):
    def __init__(self, hidden_size):
        super(SoftNoiseFilter, self).__init__()
        self.hidden_size = hidden_size
        self.filter_layer = nn.Dense(hidden_size, hidden_size)

    def construct(self, sequence_emb):
        filtered_emb = self.filter_layer(sequence_emb)
        sequence_emb = sequence_emb + filtered_emb
        return sequence_emb


class EBMRecModel(nn.Cell):
    def __init__(self, hidden_size, max_seq_length, hidden_act, num_hidden_layers, item_size, initializer_range, cuda_condition):
        super(EBMRecModel, self).__init__()
        self.hidden_size = hidden_size
        self.max_seq_length = max_seq_length
        self.hidden_act = hidden_act
        self.num_hidden_layers = num_hidden_layers
        self.item_size = item_size
        self.initializer_range = initializer_range
        self.cuda_condition = cuda_condition

        self.item_embeddings = nn.Embedding(item_size, hidden_size, padding_idx=0)
        self.position_embeddings = nn.Embedding(max_seq_length, hidden_size)
        self.LayerNorm = LayerNorm(hidden_size, eps=1e-12)
        self.dropout = nn.Dropout()
        # self.item_encoder = Encoder(hidden_size, max_seq_length, hidden_act, num_hidden_layers)

    def add_position_embedding(self, sequence):
        seq_length = sequence.shape[1]
        position_ids = Tensor(np.arange(seq_length), ms.int32)
        broadcast_to = ops.BroadcastTo(sequence.shape)
        position_ids = broadcast_to(position_ids.expand_dims(0))
        item_embeddings = self.item_embeddings(sequence)
        position_embeddings = self.position_embeddings(position_ids)
        sequence_emb = item_embeddings + position_embeddings
        sequence_emb = self.LayerNorm(sequence_emb)
        sequence_emb = self.dropout(sequence_emb)

        return sequence_emb

    def construct(self, input_ids):
        attention_mask = (input_ids > 0).astype(ms.int32)
        expand_dims = ops.ExpandDims()
        extended_attention_mask = expand_dims(attention_mask, 1)
        extended_attention_mask = expand_dims(extended_attention_mask, 2)  # torch.int64
        max_len = attention_mask.shape[-1]
        attn_shape = (1, max_len, max_len)
        subsequent_mask = Tensor(np.triu(np.ones(attn_shape), k=1), ms.int32)  # torch.uint8
        subsequent_mask = (subsequent_mask == 0).astype(ms.int32)
        subsequent_mask = expand_dims(subsequent_mask, 1)
        subsequent_mask = expand_dims(subsequent_mask, 1)
        subsequent_mask = subsequent_mask.astype(ms.int32)
        # item_encoded_layers = self.item_encoder(sequence_emb, extended_attention_mask, output_all_encoded_layers=True)
        if self.cuda_condition:
            subsequent_mask = subsequent_mask.cuda()
        extended_attention_mask = extended_attention_mask * subsequent_mask
        first_param_dtype = next(self.get_parameters())[0].dtype
        extended_attention_mask = extended_attention_mask.astype(first_param_dtype)  # fp16 compatibility
        extended_attention_mask = (1.0 - extended_attention_mask) * -10000.0
        sequence_emb = self.add_position_embedding(input_ids)

        sequence_output = sequence_emb

        return sequence_output
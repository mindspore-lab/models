# Copyright 2022 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import os
import numpy as np
import mindspore as ms
from mindspore import nn, ops, Tensor, Parameter
from mindspore.common.initializer import Normal
from mindspore.train.callback import Callback
from mindspore.dataset import GeneratorDataset
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')
from utils import recall_at_k, ndcg_k, get_metric

class CustomWithLossCell(nn.Cell):
    def __init__(self, backbone, loss_fn):
        super(CustomWithLossCell, self).__init__()
        self.backbone = backbone
        self.loss_fn = loss_fn

    def construct(self, input_ids, pos_ids, neg_ids):
        out = self.backbone(input_ids)
        return self.loss_fn(out, pos_ids, neg_ids)

class Trainer:
    def __init__(self, model, train_dataloader,
                 eval_dataloader,
                 test_dataloader, args):

        self.args = args
        self.cuda_condition = not self.args.no_cuda and ms.context.get_context('device_target') == 'GPU'
        self.device = ms.context.get_context('device_target')

        self.model = model
        if self.cuda_condition:
            self.model.set_train(True)

        self.train_dataloader = train_dataloader
        self.eval_dataloader = eval_dataloader
        self.test_dataloader = test_dataloader

        betas = (self.args.adam_beta1, self.args.adam_beta2)
        self.optim = nn.Adam(self.model.trainable_params(), learning_rate=self.args.lr, beta1=betas[0], beta2=betas[1], weight_decay=self.args.weight_decay)

        self.net_with_criterion = CustomWithLossCell(self.model, self.cross_entropy)
        self.train_one_step = nn.TrainOneStepCell(self.net_with_criterion, self.optim)

        print("Total Parameters:", sum([np.prod(p.shape) for p in self.model.trainable_params()]))

    def train(self, epoch):
        self.iteration(epoch, self.train_dataloader)

    def valid(self, epoch):
        return self.iteration(epoch, self.eval_dataloader, train=False)

    def test(self, epoch):
        return self.iteration(epoch, self.test_dataloader, train=False)

    def iteration(self, epoch, dataloader, train=True):
        str_code = "train" if train else "test"
        rec_data_iter = tqdm(enumerate(dataloader.create_tuple_iterator()),
                             desc="Recommendation EP_%s:%d" % (str_code, epoch),
                             total=dataloader.get_dataset_size(),
                             bar_format="{l_bar}{r_bar}")

        if train:
            self.model.set_train(True)
            rec_loss = 0.0

            for i, (index, input_ids, answer, neg_answer) in rec_data_iter:
                input_ids, answer, neg_answer = map(lambda x: Tensor(x, ms.int32), [input_ids, answer, neg_answer])
                loss = self.train_one_step(input_ids, answer, neg_answer)
                rec_loss += loss.asnumpy().item()

            post_fix = {
                "epoch": epoch,
                "rec_loss": '{:.4f}'.format(rec_loss / len(rec_data_iter)),
            }

            if (epoch + 1) % self.args.log_freq == 0:
                print(str(post_fix))

            with open(self.args.log_file, 'a') as f:
                f.write(str(post_fix) + '\n')

        else:
            self.model.set_train(False)
            pred_list = None
            for i, (index, input_ids, answers, _, sample_negs) in rec_data_iter:
                input_ids, answers, sample_negs = map(lambda x: Tensor(x, ms.int32), [input_ids, answers, sample_negs])
                recommend_output = self.model(input_ids)
                expand_dims = ops.ExpandDims()
                test_neg_items = ops.Concat(-1)((expand_dims(answers, -1), sample_negs))
                recommend_output = recommend_output[:, -1, :]

                test_logits = self.predict_sample(recommend_output, test_neg_items)
                test_logits = test_logits.asnumpy().copy()
                if i == 0:
                    pred_list = test_logits
                else:
                    pred_list = np.append(pred_list, test_logits, axis=0)

            return self.get_sample_scores(epoch, pred_list)

    def get_sample_scores(self, epoch, pred_list):
        pred_list = (-pred_list).argsort().argsort()[:, 0]
        HIT_1, NDCG_1, MRR = get_metric(pred_list, 1)
        HIT_5, NDCG_5, MRR = get_metric(pred_list, 5)
        HIT_10, NDCG_10, MRR = get_metric(pred_list, 10)
        post_fix = {
            "Epoch": epoch,
            "HIT@1": '{:.4f}'.format(HIT_1), "NDCG@1": '{:.4f}'.format(NDCG_1),
            "HIT@5": '{:.4f}'.format(HIT_5), "NDCG@5": '{:.4f}'.format(NDCG_5),
            "HIT@10": '{:.4f}'.format(HIT_10), "NDCG@10": '{:.4f}'.format(NDCG_10),
            "MRR": '{:.4f}'.format(MRR),
        }
        print(post_fix)
        with open(self.args.log_file, 'a') as f:
            f.write(str(post_fix) + '\n')
        return [HIT_1, NDCG_1, HIT_5, NDCG_5, HIT_10, NDCG_10, MRR], str(post_fix)

    def save(self, file_name):
        ms.save_checkpoint(self.model, file_name)

    def load(self, file_name):
        param_dict = ms.load_checkpoint(file_name)
        ms.load_param_into_net(self.model, param_dict)

    def cross_entropy(self, seq_out, pos_ids, neg_ids):
        pos_emb = self.model.item_embeddings(pos_ids)
        neg_emb = self.model.item_embeddings(neg_ids)

        seq_emb = seq_out[:, -1, :]
        pos_logits = ops.reduce_sum(pos_emb * seq_emb, -1)
        neg_logits = ops.reduce_sum(neg_emb * seq_emb, -1)

        loss = ops.reduce_mean(
            - ops.log(self.sigmoid(pos_logits) + 1e-24) -
            ops.log(1 - self.sigmoid(neg_logits) + 1e-24)
        )

        return loss
    
    def sigmoid(self, x):
        return 1 / (1 + ops.exp(-x))

    def predict_sample(self, seq_out, test_neg_sample):
        test_item_emb = self.model.item_embeddings(test_neg_sample)
        batch_matmul = ops.BatchMatMul()
        test_logits = batch_matmul(test_item_emb, seq_out.expand_dims(-1)).squeeze(-1)
        return test_logits

    def predict_full(self, seq_out):
        test_item_emb = self.model.item_embeddings.weight
        rating_pred = ops.matmul(seq_out, test_item_emb.T)
        return rating_pred

class EBMRecTrainer(Trainer):

    def __init__(self, model,
                 train_dataloader,
                 eval_dataloader,
                 test_dataloader, args):
        super(EBMRecTrainer, self).__init__(
            model,
            train_dataloader,
            eval_dataloader,
            test_dataloader, args
        )

    def iteration(self, epoch, dataloader, train=True):

        str_code = "train" if train else "test"
        rec_data_iter = tqdm(enumerate(dataloader.create_tuple_iterator()),
                             desc="Recommendation EP_%s:%d" % (str_code, epoch),
                             total=dataloader.get_dataset_size(),
                             bar_format="{l_bar}{r_bar}")

        if train:
            self.model.set_train(True)
            rec_loss = 0.0

            for i, (index, input_ids, answer, neg_answer) in rec_data_iter:
                input_ids, answer, neg_answer = map(lambda x: Tensor(x, ms.int32), [input_ids, answer, neg_answer])
                loss = self.train_one_step(input_ids, answer, neg_answer)
                rec_loss += loss.asnumpy().item()

            post_fix = {
                "epoch": epoch,
                "rec_loss": '{:.4f}'.format(rec_loss / len(rec_data_iter)),
            }

            if (epoch + 1) % self.args.log_freq == 0:
                print(str(post_fix))

            with open(self.args.log_file, 'a') as f:
                f.write(str(post_fix) + '\n')

        else:
            self.model.set_train(False)
            pred_list = None
            for i, (index, input_ids, answers, _, sample_negs) in rec_data_iter:
                input_ids, answers, sample_negs = map(lambda x: Tensor(x, ms.int32), [input_ids, answers, sample_negs])
                recommend_output = self.model(input_ids)
                expand_dims = ops.ExpandDims()
                test_neg_items = ops.Concat(-1)((expand_dims(answers, -1), sample_negs))
                recommend_output = recommend_output[:, -1, :]

                test_logits = self.predict_sample(recommend_output, test_neg_items)
                test_logits = test_logits.asnumpy().copy()
                if i == 0:
                    pred_list = test_logits
                else:
                    pred_list = np.append(pred_list, test_logits, axis=0)

            return self.get_sample_scores(epoch, pred_list)
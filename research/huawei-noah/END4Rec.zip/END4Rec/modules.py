# Copyright 2022 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================


import numpy as np
import mindspore as ms
from mindspore import nn, ops, Tensor, Parameter
from copy import deepcopy

# Activation functions
def gelu(x):
    return x * 0.5 * (1.0 + ops.Erf()(x / np.sqrt(2.0)))

def swish(x):
    return x * ops.Sigmoid()(x)

ACT2FN = {"gelu": gelu, "relu": ops.ReLU(), "swish": swish}

class LayerNorm(nn.Cell):
    def __init__(self, hidden_size, eps=1e-12):
        super(LayerNorm, self).__init__()
        self.weight = Parameter(Tensor(np.ones(hidden_size), ms.float32))
        self.bias = Parameter(Tensor(np.zeros(hidden_size), ms.float32))
        self.variance_epsilon = eps

    def construct(self, x):
        u = x.mean(axis=-1, keep_dims=True)
        s = ((x - u) ** 2).mean(axis=-1, keep_dims=True)
        x = (x - u) / ops.Sqrt()(s + self.variance_epsilon)
        return self.weight * x + self.bias

def dft_matrix(N):
    i, j = np.meshgrid(np.arange(N), np.arange(N))
    omega = np.exp(-2j * np.pi * i * j / N)
    return omega

def idft_matrix(N):
    i, j = np.meshgrid(np.arange(N), np.arange(N))
    omega = np.exp(2j * np.pi * i * j / N) / N
    return omega

class FilterLayer(nn.Cell):
    def __init__(self, hidden_size, max_seq_length):
        super(FilterLayer, self).__init__()
        self.complex_weight = Parameter(Tensor(np.random.randn(1, max_seq_length // 2 + 1, hidden_size, 2) * 0.02, ms.float32))
        self.out_dropout = nn.Dropout()
        self.LayerNorm = LayerNorm(hidden_size, eps=1e-12)
        
        self.dft_matrix = Tensor(dft_matrix(max_seq_length), dtype=ms.complex64)
        self.idft_matrix = Tensor(idft_matrix(max_seq_length), dtype=ms.complex64)

    def construct(self, input_tensor):
        batch, seq_len, hidden = input_tensor.shape
        input_tensor_complex = ops.Cast()(input_tensor, ms.complex64)
        
        # Perform DFT
        x = ops.MatMul()(input_tensor_complex, self.dft_matrix[:seq_len, :seq_len])
        
        # Apply weights (complex multiplication)
        weight = ops.Complex()(self.complex_weight[..., 0], self.complex_weight[..., 1])
        weight = weight[:, :seq_len // 2 + 1, :]
        x = x * weight
        
        # Perform IDFT
        sequence_emb_fft = ops.MatMul()(x, self.idft_matrix[:seq_len, :seq_len])
        
        # Take real part of the result
        sequence_emb_fft = ops.Real()(sequence_emb_fft)
        
        hidden_states = self.out_dropout(sequence_emb_fft)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)

        return hidden_states

class Intermediate(nn.Cell):
    def __init__(self, hidden_size, hidden_act):
        super(Intermediate, self).__init__()
        self.dense_1 = nn.Dense(hidden_size, hidden_size * 4)
        if isinstance(hidden_act, str):
            self.intermediate_act_fn = ACT2FN[hidden_act]
        else:
            self.intermediate_act_fn = hidden_act

        self.dense_2 = nn.Dense(4 * hidden_size, hidden_size)
        self.LayerNorm = LayerNorm(hidden_size, eps=1e-12)
        self.dropout = nn.Dropout()

    def construct(self, input_tensor):
        hidden_states = self.dense_1(input_tensor)
        hidden_states = self.intermediate_act_fn(hidden_states)

        hidden_states = self.dense_2(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)

        return hidden_states

class Layer(nn.Cell):
    def __init__(self, hidden_size, max_seq_length, hidden_act):
        super(Layer, self).__init__()
        self.filterlayer = FilterLayer(hidden_size, max_seq_length)
        self.intermediate = Intermediate(hidden_size, hidden_act)

    def construct(self, hidden_states, attention_mask):
        hidden_states = self.filterlayer(hidden_states)
        intermediate_output = self.intermediate(hidden_states)
        return intermediate_output

class Encoder(nn.Cell):
    def __init__(self, hidden_size, max_seq_length, hidden_act, num_hidden_layers):
        super(Encoder, self).__init__()
        layer = Layer(hidden_size, max_seq_length, hidden_act)
        self.layer = nn.CellList([deepcopy(layer) for _ in range(num_hidden_layers)])

    def construct(self, hidden_states, attention_mask, output_all_encoded_layers=True):
        all_encoder_layers = []
        for layer_module in self.layer:
            hidden_states = layer_module(hidden_states, attention_mask)
            if output_all_encoded_layers:
                all_encoder_layers.append(hidden_states)
        if not output_all_encoded_layers:
            all_encoder_layers.append(hidden_states)
        return all_encoder_layers


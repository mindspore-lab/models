# Copyright 2022 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import os
import numpy as np
import mindspore as ms
from mindspore import context, Tensor, Model, nn, ops
from mindspore.common.initializer import Normal
from tqdm import tqdm
import argparse
import mindspore.context as context
from models import EBMRecModel
from trainers import EBMRecTrainer
from utils import EarlyStopping, get_local_time, get_rating_matrix
from datasets import get_dataloader, get_seq_dic

def main():
    

    context.set_context(mode=context.PYNATIVE_MODE)

    args = argparse.Namespace(
        data_dir="./",
        output_dir="output/",
        data_name="Beauty",
        model_name="EBMRec",
        hidden_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        hidden_act="relu",
        initializer_range=0.02,
        max_seq_length=50,
        lr=0.001,
        batch_size=256,
        epochs=200,
        no_cuda=False,
        log_freq=1,
        patience=10,
        weight_decay=0.0,
        adam_beta1=0.9,
        adam_beta2=0.999,
        gpu_id="0",
        variance=5
    )

    # context.set_context(device_target="GPU" if not args.no_cuda else "CPU")
    # context.set_context(device_id=int(args.gpu_id))
    context.set_context(device_target="CPU")

    seq_dic, max_item = get_seq_dic(args)

    args.item_size = max_item + 1

    # 保存模型参数
    cur_time = get_local_time()

    args_str = f'{args.model_name}-{args.data_name}-{cur_time}'
    args.log_file = os.path.join(args.output_dir, args_str + '.txt')
    print(str(args))
    with open(args.log_file, 'a') as f:
        f.write(str(args) + '\n')

    # 保存模型
    args.checkpoint_path = os.path.join(args.output_dir, args_str + '.ckpt')

    train_dataloader, eval_dataloader, test_dataloader = get_dataloader(args, seq_dic)

    hidden_size = 64
    max_seq_length = 50
    hidden_act = "gelu"
    num_hidden_layers = 2
    item_size = max_item + 1
    initializer_range = 0.02
    cuda_condition = False

    model = EBMRecModel(hidden_size, max_seq_length, hidden_act, num_hidden_layers, item_size, initializer_range, cuda_condition)
    trainer = EBMRecTrainer(model, train_dataloader, eval_dataloader, test_dataloader, args)

    early_stopping = EarlyStopping(args.checkpoint_path, patience=args.patience, verbose=True)

    for epoch in range(args.epochs):
        trainer.train(epoch)
        scores, _ = trainer.valid(epoch)
        early_stopping(np.array(scores[-1:]), trainer.model)
        if early_stopping.early_stop:
            print("Early stopping")
            break

    print("---------------Sample 99 results---------------")
    trainer.load(args.checkpoint_path)
    scores, result_info = trainer.test(0)

    print(args_str)
    print(result_info)
    with open(args.log_file, 'a') as f:
        f.write(args_str + '\n')
        f.write(result_info + '\n')

if __name__ == "__main__":
    main()
This model is required for evaluation indicators such as BERTscore.

Since the model is large, here is its link: https://huggingface.co/google-bert/bert-base-uncased.

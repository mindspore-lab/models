# Bitstream of Secret

This directory contains 1 million randomly obtained `0, 1` bitstream, and the starting position of reading the pseudo-random bitstream is random.
